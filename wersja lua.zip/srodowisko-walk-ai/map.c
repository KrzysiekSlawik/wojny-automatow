#include "map.h"
#include "robot.h"
#include "commands.h"
#include "interpreter.h"
#include <stdlib.h>
#include <stdio.h>

map *initMap(int sizeX, int sizeY, int seed, int noisePar, int limitPar)
{
	map *newMap = calloc(1, sizeof(map));
	newMap->whole = calloc(sizeX, sizeof(int*));
	newMap->sizeX = sizeX;
	newMap->sizeY = sizeY;
	for(int i = 0; i < sizeX; i++)
	{
		newMap->whole[i] = calloc(sizeY, sizeof(int));
	}
	srand(seed);
	int randV;
	for(int x = 0; x < sizeX; x++)
	{
		for(int y = 0; y < sizeY/2; y++)
		{
			randV = rand()%noisePar - 1;
			if(randV<0)
			{
				randV = -3;
			}
			else randV = -1;
			newMap->whole[x][y] = randV;
		}
	}
	int xVec;
	int yVec;
	for(int i = 0; i < limitPar; i++)
	{
		for(int x = 0; x < sizeX; x++)
		{
			for(int y = 0; y < sizeY/2; y++)
			{
				if(newMap->whole[x][y]==-3)
				{
					xVec = rand()%3 - 1;
					yVec = rand()%3 - 1;
					if(x+xVec<sizeX && y+yVec<sizeY/2 && x+xVec>=0 && y+yVec>=0 )
					{
						newMap->whole[x+xVec][y+yVec] = -3;
						randV = rand()%5;
						if(randV!=1)randV=0;
						newMap->whole[x+xVec][y+yVec] += randV;
					}
				}
			}
		}
	}
	for(int x = 0; x < sizeX; x++)
	{
		for(int y = 0; y < sizeY/2; y++)
		{
			newMap->whole[x][sizeY-1-y]=newMap->whole[x][y];
		}
	}
	return newMap;
}
void freeMap(map* toFree)
{
	for(int x = 0; x < toFree->sizeX; x++)
	{
		free(toFree->whole[x]);
	}
	free(toFree->whole);
	free(toFree);
}
bool clearPath(map *gameMap, point a, point b)
{
	int sizeX = gameMap->sizeX;
	int sizeY = gameMap->sizeY;
	if(a.x >= sizeX || b.x >= sizeX || a.y >= sizeY || b.y >= sizeY)
	{
		return false;
	}
	int **map = calloc(sizeX, sizeof(int*));
	for(int i = 0; i < sizeX; i++)
	{
		map[i] = calloc(sizeY, sizeof(int));
	}
	for(int x = 0; x < sizeX; x++)
	{
		for(int y = 0; y < sizeY; y++)
		{
			map[x][y] = gameMap->whole[x][y];
		}
	}

	//bfs from a
	map[a.x][a.y] = 1;
	bool changed = true;
	while(changed == true)
	{
		changed = false;
		for(int x = 0; x < sizeX; x++)
		{
			for(int y = 0; y < sizeY; y++)
			{
				if(map[x][y] == 1)
				{
					//check around
					for(int i = -1; i < 2; i++)
					{
						for(int j = -1; j < 2; j++)
						{
							if((x+i<sizeX)&&(y+j<sizeY)&&(x+i>=0)&&(y+j>=0)&&(map[x+i][y+j]==-1))
							{
								if(x+i == b.x && y+j == b.y)
								{
									for(int i = 0; i < sizeX; i++)
									{
										free(map[i]);
									}
									free(map);
									return true;
								}
								map[x+i][y+j] = 1;
								changed = true;
							}
						}
					}
				}
			}
		}
	}
	for(int i = 0; i < sizeX; i++)
	{
		free(map[i]);
	}
	free(map);
	return false;
}
void initBases(map *gameMap, robot *list[ROBOTSLIMIT], int hp)
{
	list[0]->hp = hp;
	list[0]->isAlive = true;
	list[0]->isBase = true;
	list[0]->isRed = true;
	//initLuaScript(list[0]->L, "red_base.lua");
	list[0]->L = luaL_newstate();
  luaL_openlibs(list[0]->L);
  if (luaL_loadfile(list[0]->L, "red_base.lua")  || lua_pcall(list[0]->L, 0, 0, 0))
  {
    error(list[0]->L, "cannot load script file: %s\n", lua_tostring(list[0]->L, -1));
  }

	list[1]->hp = hp;
	list[1]->isAlive = true;
	list[1]->isBase = true;
	list[1]->isRed = false;
	//initLuaScript(list[1]->L, "green_base.lua");
	list[1]->L = luaL_newstate();
  luaL_openlibs(list[1]->L);
  if (luaL_loadfile(list[1]->L, "green_base.lua")  || lua_pcall(list[1]->L, 0, 0, 0))
  {
    error(list[1]->L, "cannot load script file: %s\n", lua_tostring(list[1]->L, -1));
  }


	point a, b;
	a.x = gameMap->sizeX / 2;
	b.x = a.x;
	a.y = gameMap->sizeY / 4;
	b.y = (gameMap->sizeY / 4) * 3;
	for(int yr = 0; yr < gameMap->sizeY / 3; yr++)
	{
		for(int xr = 0; xr < gameMap->sizeX / 3; xr++)
		{
			a.x += xr;
			a.y += yr;
			b.x += xr;
			b.y -= yr;
			if(clearPath(gameMap, a, b))
			{
				goto outfors;
			}
			a.x -= 2*xr;
			a.y -= 2*yr;
			b.x -= 2*xr;
			b.y += 2*yr;
			if(clearPath(gameMap, a, b))
			{
				goto outfors;
			}
			a.x += xr;
			a.y += yr;
			b.x += xr;
			b.y -= yr;
		}
	}
	//nie znaleziono dobrej pozycji, tworzenie przejścia a->b
	for(int x = -1; x < 2; x++)
	{
		for(int y = a.y-1; y < b.y+1; y++)
		{
			gameMap->whole[x][y] = -1;
		}
	}
	outfors:;
	list[0]->pos = a;
	list[1]->pos = b;

	gameMap->whole[list[0]->pos.x][list[0]->pos.y] = 0;
	gameMap->whole[list[1]->pos.x][list[1]->pos.y] = 1;
}
map *initMapfromCF(char *name)
{
	FILE *file = fopen(name, "r");
	int sizeX=0;
	int sizeY=0;
	int seed=0;
	int density=0;
	int growpar=0;
	int redResources=0;
	int greenResources=0;
	char *buff;

	buff = readWord(file);
	free(buff);
	buff = readWord(file);
	sizeX = atoi(buff);
	free(buff);

	buff = readWord(file);
	free(buff);
	buff = readWord(file);
	sizeY = atoi(buff);
	free(buff);
	//map generator works only for even sizeY, so we make sure its even
	if(sizeY%2!=0)
	{
		sizeY++;
	}

	buff = readWord(file);
	free(buff);
	buff = readWord(file);
	seed = atoi(buff);
	free(buff);

	buff = readWord(file);
	free(buff);
	buff = readWord(file);
	density = atoi(buff);
	free(buff);

	buff = readWord(file);
	free(buff);
	buff = readWord(file);
	growpar = atoi(buff);
	free(buff);

	buff = readWord(file);
	free(buff);
	buff = readWord(file);
	redResources = atoi(buff);
	free(buff);

	buff = readWord(file);
	free(buff);
	buff = readWord(file);
	greenResources = atoi(buff);
	free(buff);

	fclose(file);
	map *newMap = initMap(sizeX, sizeY, seed, density, growpar);
	newMap->resources[0] = greenResources;
	newMap->resources[1] = redResources;

	return newMap;
}
