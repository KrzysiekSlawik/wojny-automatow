#ifndef ROBOT_H
#define ROBOT_H

#include <stdbool.h>
#include <lua.h>
#include <lauxlib.h>
#include <lualib.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#ifndef ROBOTSLIMIT
#define ROBOTSLIMIT 1000
#endif
#ifndef ROBOTSRANGE
#define ROBOTSRANGE 3
#endif
#ifndef ROBOTSVISION
#define ROBOTSVISION 12
#endif
#ifndef INITIALHP
#define INITIALHP 3
#endif
#ifndef ROBOTSSIGPOW
#define ROBOTSSIGPOW 50
#endif
typedef struct point	{
	int x, y;
}point;
typedef struct robot	{
	int hp;//hit points
	point pos;//curent possition of robot
	bool isAlive, isRed, isWar, isSupp, isBase;//isRed to get nation of robot
	lua_State *L;
}robot;

#endif
