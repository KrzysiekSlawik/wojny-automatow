#ifndef COMMANDS_H
#define COMMANDS_H
#include "map.h"
#include "robot.h"
#include "interpreter.h"
#include <stdbool.h>
#include <lua.h>
#include <lauxlib.h>
#include <lualib.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
char ** visionUpdate(robot *bot, map *map);
//actual robots commands
bool moveC(robot *bot, map *map, robot *tab[ROBOTSLIMIT], int x, int y);
bool attackC(robot *bot, map *map, robot *tab[ROBOTSLIMIT], int x, int y);
bool gatherC(robot *bot, map *map, robot *tab[ROBOTSLIMIT], int x, int y);
bool produceC(robot *bot, map *map, robot *tab[ROBOTSLIMIT], char *fileName);
bool tellC(robot *bot, map *map, robot *tab[ROBOTSLIMIT], int x, int y, char *msg);
bool yellC(robot *bot, map *map, robot *tab[ROBOTSLIMIT], char *msg);
//robots service && lua
robot *initRobot(bool isRed, char *script, point pos);
void freeRobot(robot *robot);
void error(lua_State *L, const char *fmt, ...);
void initLuaScript(lua_State *L, char *file_name);
void AI(robot *bot, robot *tab[ROBOTSLIMIT], map *map);
void attackedEvent(robot *bot);
void messagedEvent(robot *bot, char *msg, int strength);
#endif
