#ifndef MAP_H
#define MAP_H


#include <stdbool.h>
#include "robot.h"
typedef struct map
{
	/*	-3 - obstacle
		-2 - gold mine
		-1 -nothing
		0-ROBOTSLIMIT - units*/
	int sizeX, sizeY;
	int **whole;
	int resources[2];
}map;
map *initMap(int sizeX, int sizeY, int seed, int noisePar, int limitPar);
void freeMap(map*);
void initBases(map *gameMap, robot *list[ROBOTSLIMIT], int hp);
map *initMapfromCF(char *name);
bool clearPath(map *gameMap, point a, point b);

#endif
