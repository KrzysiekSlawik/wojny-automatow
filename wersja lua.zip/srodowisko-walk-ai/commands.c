#include "commands.h"
#include <math.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
int distance(point p1, point p2)
{
	return sqrt(pow(p1.x - p2.x,2)+pow(p1.y - p2.y,2));
}
int sgnI(int x)
{
	if(x >= 1)return 1;
	if(x == 0)return 0;
	return -1;
}
bool pointOnMap(point p, map *map)
{
	return p.x < map->sizeX && p.x >= 0 && p.y < map->sizeY && p.y >= 0;
}
char mapTranslation(robot *tab[ROBOTSLIMIT], bool isRed, int value)
{
	if(value >= 2)
	{
		if(tab[value]->isRed != isRed) return 'e';
		else return 'f';
	}
	if(value >= 0)
	{
		if(tab[value]->isRed != isRed) return 'E';
		else return 'F';
	}
	if(value == -1) return ' ';
	if(value == -2) return 'G';
	if(value == -3) return 'O';
	return 'X';
}

void visionPush(robot *tab[ROBOTSLIMIT], robot *bot, map *map)
{
	bool isRed = bot->isRed;
	point pos = bot->pos;
	lua_State *L = bot->L;
	lua_newtable(L);
	for(int x = -ROBOTSVISION; x<=ROBOTSVISION; x++)
	{
		lua_pushnumber(L, x + ROBOTSVISION + 1);
		lua_newtable(L);
		for(int y = -ROBOTSVISION; y<=ROBOTSVISION; y++)
		{
			char *c = calloc(1, sizeof(char));
			point toTrans = {pos.x + x, pos.y + y};
			if(pointOnMap(toTrans, map))
			{
				c[0] = mapTranslation(tab, isRed, map->whole[toTrans.x][toTrans.y]);
			}
			else c[0] = 'O';
			lua_pushnumber(L, y + ROBOTSVISION + 1);
			lua_pushlstring(L, c, 1);
			lua_rawset(L, -3);
		}
		lua_rawset(L, -3);
	}
}
bool moveC(robot *bot, map *map, robot *tab[ROBOTSLIMIT], int x, int y)
{
	if(bot->isBase)
	{
		bot->isAlive = false;
		map->whole[bot->pos.x][bot->pos.y] = -1;
		return false;
	}

	point newPos;
	newPos.x = bot -> pos.x + x;
	newPos.y = bot -> pos.y + y;
	if(!pointOnMap(newPos, map))
	{
		bot->isAlive = false;
		map->whole[bot->pos.x][bot->pos.y] = -1;
		return false;
	}
	if(map->whole[newPos.x][newPos.y]==-1)
	{
		map->whole[newPos.x][newPos.y] = map->whole[bot->pos.x][bot->pos.y];
		map->whole[bot->pos.x][bot->pos.y] = -1;
		bot -> pos = newPos;
		return true;
	}
	return false;
}
bool attackC(robot *bot, map *map, robot *tab[ROBOTSLIMIT], int x, int y)
{
	if(!bot->isBase && !bot->isSupp && !bot->isWar)
	{
		bot->isWar = true;
	}
	if(!bot->isWar)
	{
		bot->isAlive = false;
		map->whole[bot->pos.x][bot->pos.y] = -1;
		return false;
	}
	point toAttack = {x, y};
	if(!pointOnMap(toAttack, map))
	{
		bot->isAlive = false;
		map->whole[bot->pos.x][bot->pos.y] = -1;
		return false;
	}
	int id = map->whole[toAttack.x][toAttack.y];
	if(id>=0)
	{
		if((tab[id]->isRed)!=(bot->isRed))
		{
			if(distance(toAttack, bot->pos)<=ROBOTSRANGE)
			{
				if(tab[id]->isAlive)
				{
					tab[id]->hp--;
					attackedEvent(tab[id]);
					if(tab[id]->hp==0)
					{
						tab[id]->isAlive = false;
						map->whole[toAttack.x][toAttack.y] = -1;
					}
				}
			}
		}
	}
	return true;
}
bool gatherC(robot *bot, map *map, robot *tab[ROBOTSLIMIT], int x, int y)
{
	if(!bot->isBase && !bot->isSupp && !bot->isWar)
	{
		bot->isSupp = true;
	}
	if(!bot->isSupp)
	{
		bot->isAlive = false;
		map->whole[bot->pos.x][bot->pos.y] = -1;
		return false;
	}
	point toGather = {x, y};
	if(!pointOnMap(toGather, map))
	{
		bot->isAlive = false;
		map->whole[bot->pos.x][bot->pos.y] = -1;
		return false;
	}
	if(ROBOTSRANGE<distance(toGather, bot->pos))return false;
	if(map->whole[toGather.x][toGather.y]==-2)
	{
		map->whole[toGather.x][toGather.y]=rand()%2 - 2;
		map->resources[(int)bot->isRed]++;
		return true;
	}
	return false;
}
bool produceC(robot *bot, map *map, robot *tab[ROBOTSLIMIT], char *fileName)
{
	if(!bot->isBase)
	{
		bot->isAlive = false;
		map->whole[bot->pos.x][bot->pos.y] = -1;
		return false;
	}
	if(map->resources[(int)bot->isRed]<1)return false;

	int idT;
	for(idT = 0; idT<=ROBOTSLIMIT; idT++)
	{
		if(!tab[idT]->isAlive)break;
	}
	if(idT==ROBOTSLIMIT)
	{
		return false;
	}
	if(map->whole[bot->pos.x-1][bot->pos.y+1]==-1)
	{
		tab[idT]->pos.x = bot->pos.x-1;
		tab[idT]->pos.y = bot->pos.y+1;
	}
	else if(map->whole[bot->pos.x][bot->pos.y+1]==-1)
	{
		tab[idT]->pos.x = bot->pos.x;
		tab[idT]->pos.y = bot->pos.y+1;
	}
	else if(map->whole[bot->pos.x+1][bot->pos.y+1]==-1)
	{
		tab[idT]->pos.x = bot->pos.x+1;
		tab[idT]->pos.y = bot->pos.y+1;
	}
	else if(map->whole[bot->pos.x+1][bot->pos.y]==-1)
	{
		tab[idT]->pos.x = bot->pos.x+1;
		tab[idT]->pos.y = bot->pos.y;
	}
	else if(map->whole[bot->pos.x+1][bot->pos.y-1]==-1)
	{
		tab[idT]->pos.x = bot->pos.x+1;
		tab[idT]->pos.y = bot->pos.y-1;
	}
	else if(map->whole[bot->pos.x][bot->pos.y-1]==-1)
	{
		tab[idT]->pos.x = bot->pos.x;
		tab[idT]->pos.y = bot->pos.y-1;
	}
	else if(map->whole[bot->pos.x-1][bot->pos.y-1]==-1)
	{
		tab[idT]->pos.x = bot->pos.x-1;
		tab[idT]->pos.y = bot->pos.y-1;
	}
	else if(map->whole[bot->pos.x-1][bot->pos.y]==-1)
	{
		tab[idT]->pos.x = bot->pos.x-1;
		tab[idT]->pos.y = bot->pos.y;
	}
	else
	{
		return false;
	}
	tab[idT]->hp = INITIALHP;
	tab[idT]->isAlive = true;
	tab[idT]->isRed = bot->isRed;
	tab[idT]->isWar = false;
	tab[idT]->isSupp = false;
	tab[idT]->isBase = false;
	if(tab[idT]->L != NULL)
	{
		lua_close(tab[idT]->L);
		tab[idT]->L = NULL;
	}
  tab[idT]->L = luaL_newstate();
  luaL_openlibs(tab[idT]->L);
  if (luaL_loadfile(tab[idT]->L, fileName)  || lua_pcall(tab[idT]->L, 0, 0, 0))
  {
    error(tab[idT]->L, "cannot load script file: %s\n", lua_tostring(tab[idT]->L, -1));
  }

	map->resources[(int)bot->isRed]-=1;
	map->whole[tab[idT]->pos.x][tab[idT]->pos.y] = idT;
	return true;
}
bool tellC(robot *bot, map *map, robot *tab[ROBOTSLIMIT], int x, int y, char *msg)
{
	point otherPos = {x, y};
	if(!pointOnMap(otherPos, map))
	{
		bot->isAlive = false;
		map->whole[bot->pos.x][bot->pos.y] = -1;
		return false;
	}
	robot *toBeMsged = tab[map->whole[x][y]];
	int sigPow = ROBOTSSIGPOW/(distance(bot->pos, otherPos)+1);
	if(sigPow == 0) return false;
	messagedEvent(toBeMsged, msg, sigPow);
	return true;
}
bool yellC(robot *bot, map *map, robot *tab[ROBOTSLIMIT], char *msg)
{
	for(int i = 0; i < ROBOTSLIMIT; i++)
	{
		robot *toBeMsged = tab[i];
		if(toBeMsged->isRed == bot->isRed)
		{
			int sigPow = ROBOTSSIGPOW/(distance(bot->pos, toBeMsged->pos)+1);
			if(sigPow != 0) messagedEvent(toBeMsged, msg, sigPow);
		}
	}
	return true;
}

robot *initRobot(bool isRed, char *script, point pos)
{
  robot *robot = calloc(1, sizeof(robot));
  robot->hp = INITIALHP;
  robot->pos = pos;
  robot->isAlive = true;
  robot->isRed = isRed;
  initLuaScript(robot->L, script);

  return robot;
}
void freeRobot(robot *robot)
{
  lua_close(robot->L);
  free(robot);
}
void error(lua_State *L, const char *fmt, ...)
{
  va_list argp;
  va_start(argp, fmt);
  vfprintf(stderr, fmt, argp);
  va_end(argp);
  lua_close(L);
  exit(1);
}

void initLuaScript(lua_State *L, char *file_name)
{
	if(L != NULL)
	{
		lua_close(L);
		L = NULL;
	}
  L = luaL_newstate();
  luaL_openlibs(L);
  if (luaL_loadfile(L, file_name)  || lua_pcall(L, 0, 0, 0))
  {
    error(L, "cannot load script file: %s\n", lua_tostring(L, -1));
  }
}
void AI(robot *bot, robot *tab[ROBOTSLIMIT], map *map)
{
	lua_State *L = bot->L;
  lua_getglobal(L, "AI");
	visionPush(tab, bot, map);
	lua_pushinteger(L, bot->pos.x);
  lua_pushinteger(L, bot->pos.y);

	char *cmdName = calloc(64, sizeof(char));
	char *msg = calloc(256, sizeof(char)); //optional
	int x; //optional
	int y; //optional
	int j = 0;

  if (lua_pcall(L, 3, LUA_MULTRET, 0) != LUA_OK)
  {
    error(L, "error running function 'AI': %s", lua_tostring(L, -1));
  }
	for(int i = 1; i <= 4; i++)
	{
		switch(lua_type(L, -1))
		{
			case LUA_TSTRING:
				if(i == 1)
				{
					msg = strncpy(msg, lua_tostring(L, -1), 256);
					j++;
				}
				else if(i - j == 1 || i - j == 3)
				{
					cmdName = strncpy(cmdName, lua_tostring(L, -1), 64);
					i = 5;//exiting for loop as we already have cmdName
				}
				else
				{
					error(L, "AI returned STRING: %s, expected NUMBER", lua_tostring(L, -1));
				}
				break;
			case LUA_TNUMBER:
				if(i - j == 1)
				{
					y = lua_tonumber(L, -1);
				}
				else if(i - j == 2)
				{
					x = lua_tonumber(L, -1);
				}
				else
				{
					error(L, "AI returned NUMBER: %d, expected STRING", lua_tonumber(L, -1));
				}
				break;
			case LUA_TNIL:
				i = 5;
				break;
			default:
				error(L, "Ai returned unexpected type %d", lua_type(L, -1));
				break;
		}
		lua_pop(L, 1);
	}
  //at this point we assume we've got cmdName
	if(strcmp(cmdName, "move") == 0)
	{
		moveC(bot, map, tab, x, y);
	}
	else if(strcmp(cmdName, "attack") == 0)
	{
		attackC(bot, map, tab, x, y);
	}
	else if(strcmp(cmdName, "gather") == 0)
	{
		gatherC(bot, map, tab, x, y);
	}
	else if(strcmp(cmdName, "produce") == 0)
	{
		produceC(bot, map, tab, msg);
	}
	else if(strcmp(cmdName, "tell") == 0)
	{
		tellC(bot, map, tab, x, y, msg);
	}
	else if(strcmp(cmdName, "yell") == 0)
	{
		yellC(bot, map, tab, msg);
	}
	else
	{
		error(L, "AI returned unknown COMMAND NAME: %s", cmdName);
	}
	free(cmdName);
	free(msg);
}
void attackedEvent(robot *bot)
{
	lua_State *L = bot->L;
  lua_getglobal(L, "ATTACKED");

  if (lua_pcall(L, 0, 0, 0) != LUA_OK)
  {
    error(L, "error running function 'AI': %s", lua_tostring(L, -1));
  }
}
void messagedEvent(robot *bot, char *msg, int strength)
{
	lua_State *L = bot->L;
  lua_getglobal(L, "MESSAGED");
	lua_pushstring(L, msg);
  lua_pushinteger(L, strength);

  if (lua_pcall(L, 2, 0, 0) != LUA_OK)
  {
    error(L, "error running function 'AI': %s", lua_tostring(L, -1));
  }
}
