#ifndef INTERPRETER_H
	#define INTERPRETER_H
	#define MAXLENGTH 20//max length of any string representing tag, function name or variable
	#include <stdbool.h>
	#include <stdio.h>
	#include "map.h"
	#include "robot.h"


	char * readWord(FILE*);//returns NULL if it fails to read word

	int tickRobots(robot**,  map*);//script *book[2][]

#endif
	
