state = nil
world = {}
world.mx = 50
world.my = 50
-- target
xt = 1
yt = 1
-- msg coords
xm = nil
ym = nil
pow = 0

file = io.open("LOG", "a")
io.output(file)

for i=1, world.mx do
  world[i] = {}
  for j=1, world.my do
    world[i][j] = " "
  end
end

function distance(x, y, xt, yt)
  return math.sqrt(math.pow(x-xt, 2)+math.pow(y-yt, 2))
end

function nearst(world, x, y, toSearch)
  local check = true
  local r = 1
  while check do
    check = false
    for i = -r, r do
      local xc = x + i
      local yc = y - r
      if pointInWorld(xc, yc, world) then
        check = true
        if world[xc][yc] == toSearch then
          return xc, yc
        end
      end
    end
    for i = -r + 1, r - 1 do
      local xc = x + r
      local yc = y + i
      if pointInWorld(xc, yc, world) then
        check = true
        if world[xc][yc] == toSearch then
          return xc, yc
        end
      end
    end
    for i = -r, r do
      local xc = x + i
      local yc = y + r
      if pointInWorld(xc, yc, world) then
        check = true
        if world[xc][yc] == toSearch then
          return xc, yc
        end
      end
    end
    for i = -r + 1, r - 1 do
      local xc = x - r
      local yc = y - i
      if pointInWorld(xc, yc, world) then
        check = true
        if world[xc][yc] == toSearch then
          return xc, yc
        end
      end
    end
    r = r + 1
  end
  return false
end


function nearstEnemy(world, x, y)
  local xe
  local ye
  xe, ye = nearst(world, x, y, "E")
  if xe and ye then
    return xe, ye
  else
    xe, ye = nearst(world, x, y, "e")
    return xe, ye
  end
end

function printWorld(world)
  io.write("\n")
  for y = 1, world.my do
    for x = 1, world.mx do
      if x == xt and y == yt then
        io.write("X")
      else
        io.write(world[x][y])
      end
    end
    io.write("\n")
  end
end
function printvision(vision)
  io.read()
  for y = 1, 25 do
    for x = 1, 25 do
      io.write(vision[x][y])
    end
    io.write("\n")
  end
end
function printvisitedworld(world, visited)
  for y = 1, world.my do
    for x = 1, world.mx do
      if visited[x][y] then
        io.write("1")
      else
        io.write("0")
      end
    end
    io.write("\n")
  end
end
function pointInWorld(x, y, world)
  if x > 0 and x <= world.mx and y > 0 and y <= world.my then
    return true
  end
  return false
end

function walkable(x, y, world)
  if pointInWorld(x, y, world) and world[x][y] == ' ' then
    return true
  end
  return false
end

function adjecentNodes(n, world, visited)
  local adjNodes = {}
  for i = -1, 1 do
    for j = -1, 1 do
      local x = i + n.x
      local y = j + n.y
      if (i ~= 0 or j ~= 0) and pointInWorld(x, y, world) and not visited[x][y] then
        visited[x][y] = true
        if walkable(x, y, world) then
          local n = initN(x, y, n)
          adjNodes[#adjNodes + 1] = n
        end
      end
    end
  end
  return adjNodes
end

function updateWorld(world, vision, x, y)
  for xi = -12, 12 do
    for yi = -12, 12 do
      if pointInWorld(xi+x+1, yi+y+1, world) and world[xi+x+1][yi+y+1] ~= "x" then
        world[xi + x + 1][yi + y + 1] = vision[xi+13][yi+13]
      end
    end
  end
end
function initN(x, y, p)
  local n = {}
  n.x = x
  n.y = y
  n.parent = p
  return n
end

function eqN(n1, n2)
  if n1.x == n2.x and n1.y == n2.y then
    return true
  end
  return false
end
function initQ(size)
  local q = {}
  q.b = 0
  q.size = 0
  q.foldpoint = size
  return q
end

function pushQ(q, e)
  q[(q.b + q.size + 1) % q.foldpoint] = e
  q.size = q.size + 1
  return q
end

function popQ(q)
  if q.size > 0 then
    local e = q[q.b + 1]
    q.size = q.size - 1
    q.b = (q.b + 1) % q.foldpoint
    return e
  end
  return nil
end

function initS(size)
  local s = {}
  s.b = 0
  s.size = 0
  s.foldpoint = size
  return s
end

function pushS(stack, e)
  if stack.size < stack.foldpoint then
    stack[(stack.b + stack.size + 1)] = e
    stack.size = stack.size + 1
    return stack
  end
end

function popS(stack)
  if stack.size ~= 0 then
    local e = stack[stack.b + stack.size]
    stack.size = stack.size - 1
    return e
  end
  return nil
end
function printS(stack)
  for i = 1, stack.size do
    print(stack[i].x, stack[i].y)
  end
end
function direction(n1, n2)
  local dir = {}
  dir.x = n1.x - n2.x
  dir.y = n1.y - n2.y
  return dir
end
function makePathStack(world, x, y)
  local node = bfsPath(world, x, y)
  if node == false then
    return false
  end
  local stack = initS(10000)
  while node.parent ~= nil do
    pushS(stack, direction(node, node.parent))
    node = node.parent
  end
  return stack
end
function bfsPath(world, x, y)
  local visited = {}
  for i=1, world.my do
    visited[i] = {}
  end
  local queue = initQ(100000)
  visited[x+1][y+1] = true
  local start_node = initN(x+1, y+1, nil)
  pushQ(queue, start_node)
  local end_node = initN(xt, yt, nil)

  while queue.size ~= 0 do
    --printvisitedworld(world, visited)
    --io.read()
    local n = popQ(queue)
    if eqN(end_node, n) then
      return n
    end
    local adjNodes = adjecentNodes(n, world, visited)
    for i = 1, #adjNodes do
      pushQ(queue, adjNodes[i])
    end
  end
  return false
end
function changeState(newState, world, x, y)
  state.exit(world, x, y)
  state = newState
  state.enter(world, x, y)
  return state.up(world, x, y)
end
------ IDLE ------
idle = {}
idle.enter = function(world, x, y)
end

idle.up = function(world, x, y)
  local xe
  local ye
  xe, ye = nearstEnemy(world, x, y)
  if xe and ye then
    local d = distance(x, y, xe, ye)
    io.write("d = ",d,"\n")
    if d < 3 then
      xt = xe
      yt = ye
      io.write("attack\n")
      return changeState(attack, world, x, y)
    else
      xt, yt = nearst(world, xe, ye, " ")
      io.write("walk\n")
      return changeState(walk, world, x, y)
    end
  else
    return "move", math.random(-1, 1), math.random(-1, 1)
  end
end

idle.exit = function(world, x, y)
  --todo
end
------ WALK ------
walk = {}
walk.enter = function(world, x, y)
  walk.path = makePathStack(world, x, y)
end

walk.up = function(world, x, y)
  if walk.path == false then
    return changeState(idle, world, x, y)
  end
  local dir = popS(walk.path)
  if dir == nil then
    return changeState(idle, world, x, y)
  end
  return "move", dir.x, dir.y
end

walk.exit = function(world, x, y)
  walk.path = nil
end

------ ATTACK ------
attack = {}
attack.enter = function(world, x, y)
end

attack.up = function(world, x, y)
  local xe
  local ye
  xe, ye = nearstEnemy(world, x, y)
  if xe and ye and distance(x, y, xe, ye) < 3 then
    io.write("succes\n")
    return "attack", xe-1, ye-1
  else
    io.write("out of range\n")
    return changeState(idle, world, x, y)
  end
end

attack.exit = function(world, x, y)
end

-----------------------
state = idle
function AI(vision, x, y)
  updateWorld(world, vision,  x, y)
  return state.up(world, x, y)
end

function ATTACKED()
  io.write("damaged\n")
end

function MESSAGED(msg, strength)
end
