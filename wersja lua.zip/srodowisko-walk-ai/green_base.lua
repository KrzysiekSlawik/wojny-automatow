function AI(map, x, y)
  return "produce", "test.lua"
end

function ATTACKED()
  x = 1
end

function MESSAGED()
  x = 1
end
print "WCZYTAŁEM"
