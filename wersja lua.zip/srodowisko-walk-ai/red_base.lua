function AI(map, x, y)
  local i = math.random(2)
  if i == 2 then
    return "produce", "test.lua"
  else
    return "yell", "propaganda"
  end
end

function ATTACKED()
  x = 1
end

function MESSAGED()
  x = 1
end
