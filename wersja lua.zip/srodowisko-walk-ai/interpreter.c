#include "interpreter.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include "interpreter.h"
#include "robot.h"
#include "commands.h"
#include "map.h"


char * readWord(FILE *file)//returns NULL if it fails to read word
{
	char *str;
	if((str = calloc(MAXLENGTH, sizeof(char)))==NULL)return NULL;
	if(fscanf(file, "%s", str)==EOF)
	{
		free(str);
		return NULL;
	}
	return str;
}

int tickRobots(robot *tab[ROBOTSLIMIT],  map *map)
{
	for(int i = 0; i < ROBOTSLIMIT; i++)
	{
		if(tab[i]->isAlive)
		{
			AI(tab[i], tab, map);
		}
		if(!tab[0]->isAlive)
		{
			//red base destroyed
			return 1;
		}
		if(!tab[1]->isAlive)
		{
			//red base destroyed
			return 2;
		}
	}
	return 0;
}
